<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Alvuxovuncarpetcleaning</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link href="favicon.jpg" rel="icon">
    <!-- CSS
	============================================ -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="assets/css/vendor/font.awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="assets/css/vendor/ionicons.min.css">
    <!-- Slick CSS -->
    <link rel="stylesheet" href="assets/css/plugins/slick.min.css">
    <!-- Animation -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- jQuery Ui -->
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
    <!-- Nice Select -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

    <!-- Vendor & Plugins CSS (Please remove the comment from below vendor.min.css & plugins.min.css for better website load performance and remove css files from the above) -->

    <!-- <link rel="stylesheet" href="assets/css/vendor/vendor.min.css">
    <link rel="stylesheet" href="assets/css/plugins/plugins.min.css"> -->

    <!-- Main Style CSS (Please use minify version for better website load performance) -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- <link rel="stylesheet" href="assets/css/style.min.css"> -->
</head>

<!-- css styling for our portfolio section -->
<style type="text/css">
.card-text{
    text-align: justify;
} 
</style>


<body>

    <div class="about-wrapper">
        <?php include 'header.php'?>

        <!-- Breadcrumb Area Start Here -->
        <div class="breadcrumbs-area position-relative mb-text-p" style="background: url('aboutbanner.jpg') no-repeat center center/cover; padding: 60px 0;">
  <div class="container">
    <div class="row">
      <div class="col-12 text-center">
        <div class="breadcrumb-content position-relative section-content" style="color: white;">
          <h3 class="title-3">About Us</h3>
          <ul style="list-style: none; padding: 0; display: inline-flex; gap: 10px; color: white;">
            <li><a href="index.php" style="color: #fff; text-decoration: underline;">Home</a></li>
            <li>About Us</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>

<section class="py-5">

  <div class="container">
<u><h2 style="text-align: center; margin-top: -83px;">About Us - Alvuxovuncarpetcleaning</h2></u>
<br>
    <div class="row align-items-center">
      
      <!-- Text Content (Left Side) -->
      <div class="col-lg-6" data-aos="fade-right">
        <h2 class="fw-bold mb-3">Welcome to Prixomozztowing</h2>
        <p style="font-size: 17px; text-align: justify;">
          Welcome to Prixomozztowing, your trusted partner for reliable and efficient towing solutions. With years of experience in the industry, we've built a reputation for exceptional service, expert care, and a commitment to getting our customers back on the road quickly. Our team of skilled professionals is equipped with state-of-the-art technology and a fleet of well-maintained vehicles, ensuring that your car is in good hands. Whether you're facing a breakdown, accident, or simply need roadside assistance, we're here to help  With a team of experienced professionals and state-of-the-art equipment, you can trust that your vehicle is in good hands. Whether you need emergency towing, roadside assistance, or specialized transportation, we're here to help.
        </p>
        
      </div>

      <!-- Image (Right Side) -->
      <div class="col-lg-6" data-aos="fade-left">
        <img src="ab1.jpg" alt="Towing Service" class="img-fluid rounded">
      </div>
    </div><br>
    <div class="row align-items-center">
      
      <!-- Text Content (Left Side) -->
      <div class="col-lg-6" data-aos="fade-left">
        <img src="ab2.jpg" alt="Towing Service" class="img-fluid rounded">
      </div>

      <!-- Image (Right Side) -->
      <div class="col-lg-6" data-aos="fade-right">
        <h2 class="fw-bold mb-3">Our Misson and Our Vision</h2>
        <p style="font-size: 17px; text-align: justify;">
          our mission is to provide exceptional towing services that exceed our customers' expectations. We're dedicated to delivering prompt, reliable, and courteous assistance, ensuring that every interaction leaves a lasting positive impression. Our goal is to be the go-to towing solution for those in need, built on a foundation of trust, expertise, and a commitment to customer satisfaction Our vision is to become the leading towing service provider in the industry, renowned for our expertise, cutting-edge technology, and unwavering dedication to customer care. We envision a future where every customer feels valued, supported, and confident in our ability to get them back on the road quickly and safely. By fostering a culture of excellence.
        </p>
        
      </div>
    </div>
  </div>
</section>
<br>
<section class="py-5 bg-white">
  <div class="container">
    <div class="text-center mb-5">
      <u><h2 class="fw-bold">Our Work Portfolio</h2></u>
      <br>
      <p class="text-muted">Take a look at some of our recent carpet and upholstery cleaning projects. We take pride in delivering spotless, fresh, and vibrant results for every client.</p>
    </div>

    <div class="row g-4">
      <!-- Portfolio Item 1 -->
      <div class="col-md-6 col-lg-4">
        <div class="card border-0 shadow h-100 text-center">
          <img src="ph1.jpg" class="card-img-top img-fluid rounded-top" alt="Living Room Carpet">
          <div class="card-body">
            <h5 class="card-title">Living Room Carpet Restoration</h5>
            <p class="card-text" style=>Revived a high-traffic carpet to look brand new, removing deep-seated dirt and stains.</p>
          </div>
        </div>
      </div>

      <!-- Portfolio Item 2 -->
      <div class="col-md-6 col-lg-4">
        <div class="card border-0 shadow h-100 text-center">
          <img src="ph2.jpg" class="card-img-top img-fluid rounded-top" alt="Office Carpet">
          <div class="card-body">
            <h5 class="card-title">Office Carpet Refresh</h5>
            <p class="card-text">Cleaned over 1,200 sq ft of office space with minimal disruption and quick drying.</p>
          </div>
        </div>
      </div>

      <!-- Portfolio Item 3 -->
      <div class="col-md-6 col-lg-4">
        <div class="card border-0 shadow h-100 text-center">
          <img src="ph3.jpg" class="card-img-top img-fluid rounded-top" alt="Stain Removal">
          <div class="card-body">
            <h5 class="card-title">Red Wine Stain Removal</h5>
            <p class="card-text">Safely eliminated tough wine stains from a white wool rug using eco-friendly products.</p>
          </div>
        </div>
      </div>

      <!-- Portfolio Item 4 -->
      <div class="col-md-6 col-lg-4">
        <div class="card border-0 shadow h-100 text-center">
          <img src="ph4.jpg" class="card-img-top img-fluid rounded-top" alt="Upholstery Sofa">
          <div class="card-body">
            <h5 class="card-title">Sofa Upholstery Deep Clean</h5>
            <p class="card-text">Transformed a heavily used sofa into a fresh and sanitized centerpiece for the living room.</p>
          </div>
        </div>
      </div>

      <!-- Portfolio Item 5 -->
      <div class="col-md-6 col-lg-4">
        <div class="card border-0 shadow h-100 text-center">
          <img src="ph5.jpg" class="card-img-top img-fluid rounded-top" alt="Pet Odor Removal">
          <div class="card-body">
            <h5 class="card-title">Pet Odor Neutralization</h5>
            <p class="card-text">Eliminated persistent pet odors and sanitized carpet fibers for a healthier home environment.</p>
          </div>
        </div>
      </div>

      <!-- Portfolio Item 6 -->
      <div class="col-md-6 col-lg-4">
        <div class="card border-0 shadow h-100 text-center">
          <img src="ph6.jpg" class="card-img-top img-fluid rounded-top" alt="Stair Carpet Clean">
          <div class="card-body">
            <h5 class="card-title">Stair Carpet Detailing</h5>
            <p class="card-text">Specialized treatment and deep cleaning for narrow stairway carpet installation.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="py-5 ">
  <div class="container">
    <div class="text-center mb-4">
      <h2 class="fw-bold">Our Happy Customers</h2>
      <p class="text-muted">See the smiles we bring with our exceptional carpet cleaning services.</p>
    </div>

    <div class="row g-4 justify-content-center">

      <!-- Customer 1 -->
      <div class="col-lg-2 col-md-4 col-sm-6">
        <div class="card h-100 border-0 shadow-sm text-center">
          <img src="per2.jpg" class="card-img-top rounded-top" alt="Customer 1">
          <div class="card-body">
            <h5 class="card-title">Emily R.</h5>
            <p style="text-align: justify;">"Sparkling clean rugs! Professional and quick service."</p>
          </div>
        </div>
      </div>

      <!-- Customer 2 -->
      <div class="col-lg-2 col-md-4 col-sm-6">
        <div class="card h-100 border-0 shadow-sm text-center">
          <img src="per1.jpg" class="card-img-top rounded-top" alt="Customer 2">
          <div class="card-body">
            <h5 class="card-title">Michael B.</h5>
            <p style="text-align: justify;">"Great job on removing tough stains—highly recommend."</p>
          </div>
        </div>
      </div>

      <!-- Customer 3 -->
      <div class="col-lg-2 col-md-4 col-sm-6">
        <div class="card h-100 border-0 shadow-sm text-center">
          <img src="per3.jpg" class="card-img-top rounded-top" alt="Customer 3">
          <div class="card-body">
            <h5 class="card-title">Sophia W.</h5>
            <p style="text-align: justify;">"My home feels fresher than ever! Superb service."</p>
          </div>
        </div>
      </div>

      <!-- Customer 4 -->
      <div class="col-lg-2 col-md-4 col-sm-6">
        <div class="card h-100 border-0 shadow-sm text-center">
          <img src="per4.jpg" class="card-img-top rounded-top" alt="Customer 4">
          <div class="card-body">
            <h5 class="card-title">James K.</h5>
            <p style="text-align: justify;">"Fast, friendly, and left the carpet looking new."</p>
          </div>
        </div>
      </div>

      <!-- Customer 5 -->
      <div class="col-lg-2 col-md-4 col-sm-6">
        <div class="card h-100 border-0 shadow-sm text-center">
          <img src="per5.jpg" class="card-img-top rounded-top" alt="Customer 5">
          <div class="card-body">
            <h5 class="card-title">Ava T.</h5>
            <p style="text-align: justify;">"The best carpet cleaning service in town, hands down."</p>
          </div>
        </div>
      </div>

    </div>
  </div>
</section>


        <!-- Feature Area End Here -->
        <!-- Newslatter Area Start Here -->
        <section style="padding: 60px 20px; background-color: #ffffff;">
  <div style="max-width: 1200px; margin: auto; text-align: center;">
    <h2 style="font-size: 36px; margin-bottom: 40px; color: #1E5631;">Latest Blogs & Articles</h2>
  </div>

  <div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 20px; max-width: 1200px; margin: auto;">

    <!-- Blog 1 -->
    <div style="flex: 1 1 calc(25% - 20px); background-color: #f9f9f9; border-radius: 10px; overflow: hidden; text-align: left;">
      <img src="b1.jpg" alt="Tips for Carpet Maintenance" style="width: 100%; height: auto;">
      <div style="padding: 15px;">
        <h3 style="font-size: 20px; color: #333;">5 Essential Carpet Maintenance Tips</h3>
        <p style="font-size: 15px; color: #666;">Learn simple ways to keep your carpet fresh and extend its life between cleanings.</p>
      </div>
    </div>

    <!-- Blog 2 -->
    <div style="flex: 1 1 calc(25% - 20px); background-color: #f9f9f9; border-radius: 10px; overflow: hidden; text-align: left;">
      <img src="b2.jpg" alt="Steam vs Dry Cleaning" style="width: 100%; height: auto;">
      <div style="padding: 15px;">
        <h3 style="font-size: 20px; color: #333;">Steam vs. Dry Carpet Cleaning</h3>
        <p style="font-size: 15px; color: #666;">Which method is better for your carpet type? Discover pros and cons in this guide.</p>
      </div>
    </div>

    <!-- Blog 3 -->
    <div style="flex: 1 1 calc(25% - 20px); background-color: #f9f9f9; border-radius: 10px; overflow: hidden; text-align: left;">
      <img src="b3.jpg" alt="Pet Odor Removal Guide" style="width: 100%; height: auto;">
      <div style="padding: 15px;">
        <h3 style="font-size: 20px; color: #333;">How to Remove Pet Odors from Carpets</h3>
        <p style="font-size: 15px; color: #666;">Step-by-step guide to eliminating unwanted smells and keeping your space fresh.</p>
      </div>
    </div>

    <!-- Blog 4 -->
    <div style="flex: 1 1 calc(25% - 20px); background-color: #f9f9f9; border-radius: 10px; overflow: hidden; text-align: left;">
      <img src="b4.jpg" alt="Carpet Stain Removal" style="width: 100%; height: auto;">
      <div style="padding: 15px;">
        <h3 style="font-size: 20px; color: #333;">Top 7 Carpet Stains and How to Treat Them</h3>
        <p style="font-size: 15px; color: #666;">From red wine to ink — we reveal how to tackle the toughest carpet stains.</p>
      </div>
    </div>

  </div>
</section>
        



        
        <!-- Footer Area Start Here -->
        <?php include 'footer.php'?>
    </div>

    <!-- Modal Area Start Here -->
    <div class="modal fade obrien-modal" id="exampleModalCenter" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close close-button" data-bs-dismiss="modal" aria-label="Close">
                    <span class="close-icon" aria-hidden="true">x</span>
                </button>
                <div class="modal-body">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 text-center">
                                <div class="product-image">
                                    <img src="assets/images/product/1.jpg" alt="Product Image">
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="modal-product">
                                    <div class="product-content">
                                        <div class="product-title">
                                            <h4 class="title">Product dummy name</h4>
                                        </div>
                                        <div class="price-box">
                                            <span class="regular-price ">$80.00</span>
                                            <span class="old-price"><del>$90.00</del></span>
                                        </div>
                                        <div class="product-rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-o"></i>
                                            <i class="fa fa-star-o"></i>
                                            <span>1 Review</span>
                                        </div>
                                        <p class="desc-content">we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame bel...</p>
                                        <form class="d-flex flex-column w-100" action="#">
                                            <div class="form-group">
                                                <select class="form-control nice-select w-100">
                                                    <option>S</option>
                                                    <option>M</option>
                                                    <option>L</option>
                                                    <option>XL</option>
                                                    <option>XXL</option>
                                                </select>
                                            </div>
                                        </form>
                                        <div class="quantity-with_btn">
                                            <div class="quantity">
                                                <div class="cart-plus-minus">
                                                    <input class="cart-plus-minus-box" value="0" type="text">
                                                    <div class="dec qtybutton">-</div>
                                                    <div class="inc qtybutton">+</div>
                                                </div>
                                            </div>
                                            <div class="add-to_cart">
                                                <a class="btn obrien-button primary-btn" href="cart.php">Add to cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Area End Here -->

    <!-- Scroll to Top Start -->
    <a class="scroll-to-top" href="#">
        <i class="ion-chevron-up"></i>
    </a>
    <!-- Scroll to Top End -->

    <!-- JS
============================================ -->

    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!-- jQuery Migrate JS -->
    <script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>
    <!-- Slick Slider JS -->
    <script src="assets/js/plugins/slick.min.js"></script>
    <!-- Countdown JS -->
    <script src="assets/js/plugins/jquery.countdown.min.js"></script>
    <!-- Ajax JS -->
    <script src="assets/js/plugins/jquery.ajaxchimp.min.js"></script>
    <!-- Jquery Nice Select JS -->
    <script src="assets/js/plugins/jquery.nice-select.min.js"></script>
    <!-- Jquery Ui JS -->
    <script src="assets/js/plugins/jquery-ui.min.js"></script>
    <!-- jquery magnific popup js -->
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

</body>

</html>