<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Alvuxovuncarpetcleaning</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
   <link href="favicon.jpg" rel="icon">

    <!-- CSS
	============================================ -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="assets/css/vendor/font.awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="assets/css/vendor/ionicons.min.css">
    <!-- Slick CSS -->
    <link rel="stylesheet" href="assets/css/plugins/slick.min.css">
    <!-- Animation -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- jQuery Ui -->
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
    <!-- Nice Select -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

    <!-- Vendor & Plugins CSS (Please remove the comment from below vendor.min.css & plugins.min.css for better website load performance and remove css files from the above) -->

    <!-- <link rel="stylesheet" href="assets/css/vendor/vendor.min.css">
    <link rel="stylesheet" href="assets/css/plugins/plugins.min.css"> -->

    <!-- Main Style CSS (Please use minify version for better website load performance) -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- <link rel="stylesheet" href="assets/css/style.min.css"> -->
</head>
<style type="text/css">
    .nav-link {
    font-size: 16px;
    color: #6c757d;
    font-weight: 500;
}

.nav-link:hover {
    color: #000;
}

.btn {
    font-weight: 500;
}
<style>
        /* Base Styles */
        :root {
            --primary-color: #2a5d84;
            --secondary-color: #f8f8f8;
            --accent-color: #ff7e33;
            --text-color: #333;
            --light-text: #777;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: var(--text-color);
        }
        
        .services-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
        }
        
        .section-title {
            text-align: center;
            margin-bottom: 50px;
            color: var(--primary-color);
        }
        
        .section-title h2 {
            font-size: 2.5rem;
            margin-bottom: 15px;
        }
        
        .section-title p {
            font-size: 1.1rem;
            color: var(--light-text);
            max-width: 700px;
            margin: 0 auto;
        }
        
        /* Services Grid */
        .services-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }
        
        .service-card {
            background: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .service-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }
        
        .service-icon {
            background-color: var(--primary-color);
            color: white;
            font-size: 2.5rem;
            padding: 25px 0;
            text-align: center;
        }
        
        .service-content {
            padding: 25px;
        }
        
        .service-content h3 {
            font-size: 1.5rem;
            margin-bottom: 15px;
            color: var(--primary-color);
        }
        
        .service-content p {
            color: var(--light-text);
            margin-bottom: 20px;
        }
        
        .learn-more {
            display: inline-block;
            color: var(--accent-color);
            font-weight: 600;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        
        .learn-more:hover {
            color: var(--primary-color);
        }
        
        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .section-title h2 {
                font-size: 2rem;
            }
            
            .services-grid {
                grid-template-columns: 1fr;
            }
        }
</style>
<body>
<?php include 'header.php'?>

       
        <section class="hero-banner" style="background: url('img.jpg') center center / cover no-repeat; padding: 100px 20px; text-align: center; position: relative; color: white;">
  <div style=" padding: 60px 20px; border-radius: 10px; max-width: 800px; margin: auto;">
    <h1 style="font-size: 48px; font-weight: bold; margin-bottom: 20px; color: #FFCC00;">
  Welcome to Alvuxovuncarpetcleaning
</h1>

<p style="font-size: 20px; margin-bottom: 30px; color:black; text-align:justify;">
  Welcome to Alvuxovuncarpetcleaning, your premier destination for professional carpet cleaning services. At Alvuxovuncarpetcleaning, we understand the importance of clean carpets in maintaining a healthy and comfortable home or office environment. Our team of experienced technicians is dedicated to providing top-notch carpet cleaning services that not only leave your carpets looking their best but also contribute to a cleaner and healthier indoor air quality.
</p>

<a href="about.php" style="background-color: #1E5631; padding: 12px 30px; color: #fff; font-size: 18px; border-radius: 6px; text-decoration: none; font-weight: 600;">
  Book Now
</a>

  </div>
</section>

        <!-- Slider Area One End Here -->
        <!-- Feature Area Start Here -->
        <section style="padding: 60px 20px; ">
  <div style="max-width: 1200px; margin: auto; display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between;">
    
    <!-- Left Side: Image -->
    <div style="flex: 1 1 48%; padding: 10px; text-align: center;">
      <img src="pic1.jpg" alt="Carpet Cleaning" style="width: 100%; height: auto; border-radius: 10px;">
    </div>

    <!-- Right Side: Text Content -->
    <div style="flex: 1 1 48%; padding: 10px;">
      <h2>
       BEST CARPET CLEANING SOLUTIONS FOR EVERYONE
      </h2>
      
      <p style="font-size: 19px;  color:black; text-align:justify;">
        At Alvuxovuncarpetcleaning, we offer the best carpet cleaning solutions for everyone. Our comprehensive range of services is designed to cater to the unique needs of residential, commercial, and industrial clients. 
        We provide deep cleaning, stain removal, sanitizing, and deodorizing services that leave your carpets looking their best and contributing to a healthier indoor air quality.
      </p>
      <br>
     
    </div><br>
    <div style="flex: 1 1 48%; padding: 10px;">
      <h2>
       FULLY CUSTOMIZED AND ENHANCED SERVICES
      </h2>
      
      <p style="font-size: 19px;  color:black; text-align:justify;">
        By choosing our carpet cleaning solutions, you can enjoy a range of benefits, including improved indoor air quality, extended carpet life, increased property value, and a healthier environment for you and your loved ones. 
        Our team is dedicated to delivering exceptional service, unparalleled quality, and customer satisfaction we offer fully customized and enhanced services tailored to meet the unique needs of each client.
      </p>
      <br>
      
    </div>
    <div style="flex: 1 1 48%; padding: 10px; text-align: center;">
      <img src="pic2.jpg" alt="Carpet Cleaning" style="width: 100%; height: auto; border-radius: 10px;">
    </div>
  </div>
</section>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">

         <section class="services-container">
        <div class="section-title">
            <h2>Professional Carpet Cleaning Services</h2>
            <p>We provide top-quality carpet cleaning solutions tailored to your needs, using eco-friendly products and state-of-the-art equipment.</p>
        </div>
        
        <div class="services-grid">
            <!-- First Row -->
            <div class="service-card">
                <div class="service-icon">
                    <i>🧼</i> <!-- Icon placeholder - replace with actual icon -->
                </div>
                <div class="service-content">
                    <h3>Deep Steam Cleaning</h3>
                    <p>Our advanced steam cleaning penetrates deep into carpet fibers, removing stubborn dirt, allergens, and bacteria while extending your carpet's lifespan.</p>
                    <a href="#" class="learn-more">Learn more →</a>
                </div>
            </div>
            
            <div class="service-card">
                <div class="service-icon">
                    <i>🛡️</i>
                </div>
                <div class="service-content">
                    <h3>Stain Protection</h3>
                    <p>Professional stain protection treatment creates an invisible barrier that repels liquids and prevents future stains, keeping your carpets looking newer longer.</p>
                    <a href="#" class="learn-more">Learn more →</a>
                </div>
            </div>
            
            <div class="service-card">
                <div class="service-icon">
                    <i>🌿</i>
                </div>
                <div class="service-content">
                    <h3>Eco-Friendly Cleaning</h3>
                    <p>We use certified green cleaning solutions that are safe for your family, pets, and the environment while delivering exceptional cleaning results.</p>
                    <a href="#" class="learn-more">Learn more →</a>
                </div>
            </div>
            
            <!-- Second Row -->
            <div class="service-card">
                <div class="service-icon">
                    <i>🚗</i>
                </div>
                <div class="service-content">
                    <h3>Upholstery Cleaning</h3>
                    <p>Expert cleaning for your furniture, curtains, and car interiors using specialized techniques that protect fabrics while removing deep-seated dirt.</p>
                    <a href="#" class="learn-more">Learn more →</a>
                </div>
            </div>
            
            <div class="service-card">
                <div class="service-icon">
                    <i>🕒</i>
                </div>
                <div class="service-content">
                    <h3>Quick-Dry Service</h3>
                    <p>Our proprietary quick-dry technology allows your carpets to be ready for use in just 2-4 hours, minimizing disruption to your daily routine.</p>
                    <a href="#" class="learn-more">Learn more →</a>
                </div>
            </div>
            
            <div class="service-card">
                <div class="service-icon">
                    <i>🏢</i>
                </div>
                <div class="service-content">
                    <h3>Commercial Cleaning</h3>
                    <p>Customized cleaning programs for businesses, offices, and commercial spaces with flexible scheduling to meet your operational needs.</p>
                    <a href="#" class="learn-more">Learn more →</a>
                </div>
            </div>
        </div>
    </section>
        <!-- Banner Fullwidth Area End Here -->
        <!-- Banner Area Start Here -->
        
        <!-- Product Area Start Here -->
        <section style="padding: 60px 20px; ">
  <div style="max-width: 1200px; margin: auto; text-align: center;">
    <h2 style="font-size: 36px; margin-bottom: 40px; color: #1E5631;">Our Features</h2>
  </div>

  <div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 30px; max-width: 1200px; margin: auto;">

    <!-- Feature 1 -->
    <div style="flex: 1 1 calc(50% - 30px); text-align: center;">
      <img src="k1.jpg" alt="Deep Carpet Cleaning" style="width: 100%; height: auto; border-radius: 10px;">
      <h3 style="margin-top: 15px; font-size: 22px; color: #333;">Deep Carpet Cleaning</h3>
      
      <p style="font-size: 16px; text-align: justify;">Removes embedded dirt and allergens for a fresher, healthier home environment.</p>
    </div>

    <!-- Feature 2 -->
    <div style="flex: 1 1 calc(50% - 30px); text-align: center;">
      <img src="k2.jpg" alt="Steam Treatment" style="width: 100%; height: auto; border-radius: 10px;">
      <h3 style="margin-top: 15px; font-size: 22px; color: #333;">Steam Carpet Treatment</h3>
      <p style="font-size: 16px; color: #666;">Advanced steam cleaning technology that lifts stains and sanitizes surfaces effectively.</p>
    </div>

    <!-- Feature 3 -->
    <div style="flex: 1 1 calc(50% - 30px); text-align: center;">
      <img src="k3.jpg" alt="Odor Elimination" style="width: 100%; height: auto; border-radius: 10px;">
      <h3 style="margin-top: 15px; font-size: 22px; color: #333;">Pet Odor Removal</h3>
      <p style="font-size: 16px; text-align: justify;">Neutralizes tough pet odors and leaves your carpet smelling clean and refreshed.</p>
    </div>

    <!-- Feature 4 -->
    <div style="flex: 1 1 calc(50% - 30px); text-align: center;">
      <img src="k4.jpg" alt="Stain Removal" style="width: 100%; height: auto; border-radius: 10px;">
      <h3 style="margin-top: 15px; font-size: 22px; color: #333;">Stain Removal Experts</h3>
      <p style="font-size: 16px; text-align: justify;">We specialize in eliminating stubborn stains including wine, coffee, ink, and more.</p>
    </div>

  </div>
</section>

        
        <section style="padding: 60px 20px; background-color: #ffffff;">
  <div style="max-width: 1200px; margin: auto; text-align: center;">
    <h2 style="font-size: 36px; margin-bottom: 40px; color: #1E5631;">Latest Blogs & Articles</h2>
  </div>

  <div style="display: flex; flex-wrap: wrap; justify-content: space-between; gap: 20px; max-width: 1200px; margin: auto;">

    <!-- Blog 1 -->
    <div style="flex: 1 1 calc(25% - 20px); background-color: #f9f9f9; border-radius: 10px; overflow: hidden; text-align: left;">
      <img src="b1.jpg" alt="Tips for Carpet Maintenance" style="width: 100%; height: auto;">
      <div style="padding: 15px;">
        <h3 style="font-size: 20px; color: #333;">5 Essential Carpet Maintenance Tips</h3>
        <p style="font-size: 15px; color: #666;">Learn simple ways to keep your carpet fresh and extend its life between cleanings.</p>
      </div>
    </div>

    <!-- Blog 2 -->
    <div style="flex: 1 1 calc(25% - 20px); background-color: #f9f9f9; border-radius: 10px; overflow: hidden; text-align: left;">
      <img src="b2.jpg" alt="Steam vs Dry Cleaning" style="width: 100%; height: auto;">
      <div style="padding: 15px;">
        <h3 style="font-size: 20px; color: #333;">Steam vs. Dry Carpet Cleaning</h3>
        <p style="font-size: 15px; color: #666;">Which method is better for your carpet type? Discover pros and cons in this guide.</p>
      </div>
    </div>

    <!-- Blog 3 -->
    <div style="flex: 1 1 calc(25% - 20px); background-color: #f9f9f9; border-radius: 10px; overflow: hidden; text-align: left;">
      <img src="b3.jpg" alt="Pet Odor Removal Guide" style="width: 100%; height: auto;">
      <div style="padding: 15px;">
        <h3 style="font-size: 20px; color: #333;">How to Remove Pet Odors from Carpets</h3>
        <p style="font-size: 15px; color: #666;">Step-by-step guide to eliminating unwanted smells and keeping your space fresh.</p>
      </div>
    </div>

    <!-- Blog 4 -->
    <div style="flex: 1 1 calc(25% - 20px); background-color: #f9f9f9; border-radius: 10px; overflow: hidden; text-align: left;">
      <img src="b4.jpg" alt="Carpet Stain Removal" style="width: 100%; height: auto;">
      <div style="padding: 15px;">
        <h3 style="font-size: 20px; color: #333;">Top 7 Carpet Stains and How to Treat Them</h3>
        <p style="font-size: 15px; color: #666;">From red wine to ink — we reveal how to tackle the toughest carpet stains.</p>
      </div>
    </div>

  </div>
</section>

        <!-- Support Area End Here -->
        <!-- Footer Area Start Here -->
        <?php include 'footer.php'?>
        <!-- Footer Area End Here -->
    </div>

    <!-- Modal Area Start Here -->
    <div class="modal fade Alvuxovuncarpetcleaning-modal" id="exampleModalCenter" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close close-button" data-bs-dismiss="modal" aria-label="Close">
                    <span class="close-icon" aria-hidden="true">x</span>
                </button>
                <div class="modal-body">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 text-center">
                                <div class="product-image">
                                    <img src="assets/images/product/1.jpg" alt="Product Image">
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="modal-product">
                                    <div class="product-content">
                                        <div class="product-title">
                                            <h4 class="title">Product dummy name</h4>
                                        </div>
                                        <div class="price-box">
                                            <span class="regular-price ">$80.00</span>
                                            <span class="old-price"><del>$90.00</del></span>
                                        </div>
                                        <div class="product-rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-o"></i>
                                            <i class="fa fa-star-o"></i>
                                            <span>1 Review</span>
                                        </div>
                                        <p class="desc-content">we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame bel...</p>
                                        <form class="d-flex flex-column w-100" action="#">
                                            <div class="form-group">
                                                <select class="form-control nice-select w-100">
                                                    <option>S</option>
                                                    <option>M</option>
                                                    <option>L</option>
                                                    <option>XL</option>
                                                    <option>XXL</option>
                                                </select>
                                            </div>
                                        </form>
                                        <div class="quantity-with_btn">
                                            <div class="quantity">
                                                <div class="cart-plus-minus">
                                                    <input class="cart-plus-minus-box" value="0" type="text">
                                                    <div class="dec qtybutton">-</div>
                                                    <div class="inc qtybutton">+</div>
                                                </div>
                                            </div>
                                            <div class="add-to_cart">
                                                <a class="btn Alvuxovuncarpetcleaning-button primary-btn" href="cart.php">Add to cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Area End Here -->

    <!-- Scroll to Top Start -->
    <a class="scroll-to-top" href="#">
        <i class="ion-chevron-up"></i>
    </a>
    <!-- Scroll to Top End -->

    <!-- JS
============================================ -->

    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!-- jQuery Migrate JS -->
    <script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>
    <!-- Slick Slider JS -->
    <script src="assets/js/plugins/slick.min.js"></script>
    <!-- Countdown JS -->
    <script src="assets/js/plugins/jquery.countdown.min.js"></script>
    <!-- Ajax JS -->
    <script src="assets/js/plugins/jquery.ajaxchimp.min.js"></script>
    <!-- Jquery Nice Select JS -->
    <script src="assets/js/plugins/jquery.nice-select.min.js"></script>
    <!-- Jquery Ui JS -->
    <script src="assets/js/plugins/jquery-ui.min.js"></script>
    <!-- jquery magnific popup js -->
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

</body>

</html>