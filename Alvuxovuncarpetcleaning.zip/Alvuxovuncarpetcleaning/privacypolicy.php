<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Alvuxovuncarpetcleaning</title>
   
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link href="favicon.jpg" rel="icon">

    <!-- CSS
	============================================ -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="assets/css/vendor/font.awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="assets/css/vendor/ionicons.min.css">
    <!-- Slick CSS -->
    <link rel="stylesheet" href="assets/css/plugins/slick.min.css">
    <!-- Animation -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- jQuery Ui -->
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
    <!-- Nice Select -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

    <!-- Vendor & Plugins CSS (Please remove the comment from below vendor.min.css & plugins.min.css for better website load performance and remove css files from the above) -->

    <!-- <link rel="stylesheet" href="assets/css/vendor/vendor.min.css">
    <link rel="stylesheet" href="assets/css/plugins/plugins.min.css"> -->

    <!-- Main Style CSS (Please use minify version for better website load performance) -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- <link rel="stylesheet" href="assets/css/style.min.css"> -->
</head>

<body>

    <div class="blog-wrapper">
        <?php include 'header.php'?>
        <!-- Breadcrumb Area Start Here -->
        <div class="breadcrumbs-area position-relative mb-text-p" style="background: url('aboutbanner.jpg') no-repeat center center/cover; padding: 60px 0;">
  <div class="container">
    <div class="row">
      <div class="col-12 text-center">
        <div class="breadcrumb-content position-relative section-content" style="color: white;">
          <h3 class="title-3">Privacy Policy</h3>
          <ul style="list-style: none; padding: 0; display: inline-flex; gap: 10px; color: white;">
            <li><a href="index.php" style="color: #fff; text-decoration: underline;">Home</a></li>
            <li>About Us</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>

        <!-- Breadcrumb Area End Here -->
        <!-- Blog Main Area Start Here -->
        <section style="padding: 20px 20px;">
  <div style="max-width: 1000px; margin: auto;">
    <u><h2 style="text-align: center; font-size: 36px; margin-bottom: 40px; color: #1E5631;">Privacy Policy - Alvuxovuncarpetcleaning</h2></u>

    <div style="font-size: 16px; line-height: 1.7; color: #333;">

      <h3>1. Introduction</h3>
      <p>Welcome to Alvuxovuncarpetcleaning. Your privacy is important to us. This Privacy Policy outlines how we collect, use, and protect your information.</p>
      <br>
      <h3>2. Information We Collect</h3>
      <p>We collect personal information such as your name, contact details, service preferences, and payment data when you use our services or website.</p>
      <br>
      <h3>3. How We Use Your Information</h3>
      <p>Your information is used to provide services, process payments, send updates, and improve our offerings.</p>
      <br>
      <h3>4. Sharing Your Information</h3>
      <p>We do not sell your data. We may share information with trusted third parties who assist in service delivery, under strict confidentiality.</p>
       <br>
      <h3>5. Cookies and Tracking</h3>
      <p>Our site uses cookies to enhance user experience, track website usage, and serve relevant content.</p>
      <br>
      <h3>6. Data Security</h3>
      <p>We use industry-standard encryption and security measures to protect your personal information.</p>
      <br>
      <h3>7. Third-Party Links</h3>
      <p>Our website may contain links to third-party websites. We are not responsible for their privacy practices.</p>
      <br>
      <h3>8. Data Retention</h3>
      <p>We retain your personal data only as long as necessary for business and legal purposes.</p>
       <br>
      <h3>9. Children's Privacy</h3>
      <p>Our services are not intended for individuals under 13. We do not knowingly collect data from minors.</p>
      <br>
      <h3>10. Your Data Rights</h3>
      <p>You have the right to access, correct, or delete your personal data by contacting us directly.</p>
      <br>
      <h3>11. Email Marketing</h3>
      <p>We may send promotional emails. You can opt-out anytime via the unsubscribe link in our emails.</p>
      <br>
      <h3>12. Service-Specific Privacy</h3>
      <p>Certain services may have additional privacy provisions, which will be communicated during use.</p>
       <br>
      <h3>13. Location Data</h3>
      <p>We may collect location data to offer better local service. This data is only used with your consent.</p>
      <br>
      <h3>14. Changes to This Policy</h3>
      <p>We may update this Privacy Policy from time to time. Changes will be posted on this page with the updated date.</p>
      <br>
      <h3>15. Contact Us</h3>
      <p>If you have any questions or concerns about our Privacy Policy, please contact us at support@alvuxovuncarpetcleaning.com.</p>

    </div>
  </div>
</section>

        <!-- Support Area End Here -->
        <!-- Footer Area Start Here -->
        <?php include 'footer.php'?>
    </div>

    <!-- Modal Area Start Here -->
    <div class="modal fade obrien-modal" id="exampleModalCenter" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close close-button" data-bs-dismiss="modal" aria-label="Close">
                    <span class="close-icon" aria-hidden="true">x</span>
                </button>
                <div class="modal-body">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 text-center">
                                <div class="product-image">
                                    <img src="assets/images/product/1.jpg" alt="Product Image">
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="modal-product">
                                    <div class="product-content">
                                        <div class="product-title">
                                            <h4 class="title">Product dummy name</h4>
                                        </div>
                                        <div class="price-box">
                                            <span class="regular-price ">$80.00</span>
                                            <span class="old-price"><del>$90.00</del></span>
                                        </div>
                                        <div class="product-rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-o"></i>
                                            <i class="fa fa-star-o"></i>
                                            <span>1 Review</span>
                                        </div>
                                        <p class="desc-content">we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame bel...</p>
                                        <form class="d-flex flex-column w-100" action="#">
                                            <div class="form-group">
                                                <select class="form-control nice-select w-100">
                                                    <option>S</option>
                                                    <option>M</option>
                                                    <option>L</option>
                                                    <option>XL</option>
                                                    <option>XXL</option>
                                                </select>
                                            </div>
                                        </form>
                                        <div class="quantity-with_btn">
                                            <div class="quantity">
                                                <div class="cart-plus-minus">
                                                    <input class="cart-plus-minus-box" value="0" type="text">
                                                    <div class="dec qtybutton">-</div>
                                                    <div class="inc qtybutton">+</div>
                                                </div>
                                            </div>
                                            <div class="add-to_cart">
                                                <a class="btn obrien-button primary-btn" href="cart.php">Add to cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Area End Here -->

    <!-- Scroll to Top Start -->
    <a class="scroll-to-top" href="#">
        <i class="ion-chevron-up"></i>
    </a>
    <!-- Scroll to Top End -->

    <!-- JS
============================================ -->

    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!-- jQuery Migrate JS -->
    <script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>
    <!-- Slick Slider JS -->
    <script src="assets/js/plugins/slick.min.js"></script>
    <!-- Countdown JS -->
    <script src="assets/js/plugins/jquery.countdown.min.js"></script>
    <!-- Ajax JS -->
    <script src="assets/js/plugins/jquery.ajaxchimp.min.js"></script>
    <!-- Jquery Nice Select JS -->
    <script src="assets/js/plugins/jquery.nice-select.min.js"></script>
    <!-- Jquery Ui JS -->
    <script src="assets/js/plugins/jquery-ui.min.js"></script>
    <!-- jquery magnific popup js -->
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

</body>

</html>