<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Alvuxovuncarpetcleaning</title>
   
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link href="favicon.jpg" rel="icon">

    <!-- CSS
	============================================ -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="assets/css/vendor/bootstrap.min.css">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="assets/css/vendor/font.awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="assets/css/vendor/ionicons.min.css">
    <!-- Slick CSS -->
    <link rel="stylesheet" href="assets/css/plugins/slick.min.css">
    <!-- Animation -->
    <link rel="stylesheet" href="assets/css/plugins/animate.min.css">
    <!-- jQuery Ui -->
    <link rel="stylesheet" href="assets/css/plugins/jquery-ui.min.css">
    <!-- Nice Select -->
    <link rel="stylesheet" href="assets/css/plugins/nice-select.min.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="assets/css/plugins/magnific-popup.css">

    <!-- Vendor & Plugins CSS (Please remove the comment from below vendor.min.css & plugins.min.css for better website load performance and remove css files from the above) -->

    <!-- <link rel="stylesheet" href="assets/css/vendor/vendor.min.css">
    <link rel="stylesheet" href="assets/css/plugins/plugins.min.css"> -->

    <!-- Main Style CSS (Please use minify version for better website load performance) -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- <link rel="stylesheet" href="assets/css/style.min.css"> -->
</head>

<body>

    <div class="blog-wrapper">
        <?php include 'header.php'?>
        <!-- Breadcrumb Area Start Here -->
        <div class="breadcrumbs-area position-relative mb-text-p" style="background: url('aboutbanner.jpg') no-repeat center center/cover; padding: 60px 0;">
  <div class="container">
    <div class="row">
      <div class="col-12 text-center">
        <div class="breadcrumb-content position-relative section-content" style="color: white;">
          <h3 class="title-3">Sparkle & Shine Cleaning</h3>
          <ul style="list-style: none; padding: 0; display: inline-flex; gap: 10px; color: white;">
            <li><a href="index.php" style="color: #fff; text-decoration: underline;">Home</a></li>
            <li>Sparkle & Shine Cleaning</li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>

        <!-- Breadcrumb Area End Here -->
        <!-- Blog Main Area Start Here -->
        <section style="padding: 40px 20px;">
  <div style="max-width: 1000px; margin: auto; text-align: center;">
    
    <!-- Main Heading -->
    <u><h2 style="font-size: 36px; margin-bottom: 20px; color: #1E5631;">Sparkle & Shine Cleaning</h2></u>
    
    <!-- Main Description -->
    <p style="font-size: 17px; color: #333; line-height: 1.7; margin-bottom: 40px; text-align: justify;">
      At Alvuxovuncarpetcleaning, we believe a truly clean home goes beyond the surface. Our Sparkle & Shine Cleaning service transforms your carpets and upholstery with precision, care, and eco-conscious solutions. We’re committed to creating a healthier, fresher environment for your family to enjoy.
    </p>

    <!-- Center Image -->
    <img src="serv2.jpg" alt="Sparkle & Shine Cleaning" style="max-width: 100%; height: auto; border-radius: 12px; margin-bottom: 40px; box-shadow: 0 4px 10px rgba(0,0,0,0.1);" />

    <!-- Subpoints -->
    <div style="text-align: left; font-size: 16px; line-height: 1.7; color: #333;">

      <h4 style="color: #1E5631;">✓ Deep Carpet Restoration</h4>
      <p>We remove dirt, grime, and stubborn stains deeply embedded in your carpet fibers, bringing back their original softness and vibrance.</p>
      <br>

      <h4 style="color: #1E5631;">✓ Allergy & Odor Elimination</h4>
      <p>Our cleaning removes allergens and pet odors, ensuring a fresh, breathable space for everyone in your home.</p>
      <br>

      <h4 style="color: #1E5631;">✓ Quick Dry Finish</h4>
      <p>Our fast-dry technology ensures minimal disruption, allowing you to return to your cleaned spaces in just a few hours.</p>

    </div>
  </div>
</section>


        <!-- Support Area End Here -->
        <!-- Footer Area Start Here -->
        <?php include 'footer.php'?>
    </div>

    <!-- Modal Area Start Here -->
    <div class="modal fade obrien-modal" id="exampleModalCenter" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <button type="button" class="close close-button" data-bs-dismiss="modal" aria-label="Close">
                    <span class="close-icon" aria-hidden="true">x</span>
                </button>
                <div class="modal-body">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-6 col-md-6 text-center">
                                <div class="product-image">
                                    <img src="assets/images/product/1.jpg" alt="Product Image">
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6">
                                <div class="modal-product">
                                    <div class="product-content">
                                        <div class="product-title">
                                            <h4 class="title">Product dummy name</h4>
                                        </div>
                                        <div class="price-box">
                                            <span class="regular-price ">$80.00</span>
                                            <span class="old-price"><del>$90.00</del></span>
                                        </div>
                                        <div class="product-rating">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star-o"></i>
                                            <i class="fa fa-star-o"></i>
                                            <span>1 Review</span>
                                        </div>
                                        <p class="desc-content">we denounce with righteous indignation and dislike men who are so beguiled and demoralized by the charms of pleasure of the moment, so blinded by desire, that they cannot foresee the pain and trouble that are bound to ensue; and equal blame bel...</p>
                                        <form class="d-flex flex-column w-100" action="#">
                                            <div class="form-group">
                                                <select class="form-control nice-select w-100">
                                                    <option>S</option>
                                                    <option>M</option>
                                                    <option>L</option>
                                                    <option>XL</option>
                                                    <option>XXL</option>
                                                </select>
                                            </div>
                                        </form>
                                        <div class="quantity-with_btn">
                                            <div class="quantity">
                                                <div class="cart-plus-minus">
                                                    <input class="cart-plus-minus-box" value="0" type="text">
                                                    <div class="dec qtybutton">-</div>
                                                    <div class="inc qtybutton">+</div>
                                                </div>
                                            </div>
                                            <div class="add-to_cart">
                                                <a class="btn obrien-button primary-btn" href="cart.php">Add to cart</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Modal Area End Here -->

    <!-- Scroll to Top Start -->
    <a class="scroll-to-top" href="#">
        <i class="ion-chevron-up"></i>
    </a>
    <!-- Scroll to Top End -->

    <!-- JS
============================================ -->

    <!-- jQuery JS -->
    <script src="assets/js/vendor/jquery-3.6.0.min.js"></script>
    <!-- jQuery Migrate JS -->
    <script src="assets/js/vendor/jquery-migrate-3.3.2.min.js"></script>
    <!-- Modernizer JS -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="assets/js/vendor/bootstrap.bundle.min.js"></script>
    <!-- Slick Slider JS -->
    <script src="assets/js/plugins/slick.min.js"></script>
    <!-- Countdown JS -->
    <script src="assets/js/plugins/jquery.countdown.min.js"></script>
    <!-- Ajax JS -->
    <script src="assets/js/plugins/jquery.ajaxchimp.min.js"></script>
    <!-- Jquery Nice Select JS -->
    <script src="assets/js/plugins/jquery.nice-select.min.js"></script>
    <!-- Jquery Ui JS -->
    <script src="assets/js/plugins/jquery-ui.min.js"></script>
    <!-- jquery magnific popup js -->
    <script src="assets/js/plugins/jquery.magnific-popup.min.js"></script>

    <!-- Main JS -->
    <script src="assets/js/main.js"></script>

</body>

</html>